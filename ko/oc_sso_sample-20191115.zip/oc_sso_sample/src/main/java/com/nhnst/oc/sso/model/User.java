package com.nhnst.oc.sso.model;

import java.io.Serializable;

public class User implements Serializable {

	private static final long serialVersionUID = 3156056297932511044L;
	
	private String userCode;
	
	private String userName;
	
	private String email;
	
	private String phone;

	public String getUserCode() {
		return userCode;
	}

	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

}

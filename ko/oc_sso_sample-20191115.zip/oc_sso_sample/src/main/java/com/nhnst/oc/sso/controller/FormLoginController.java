package com.nhnst.oc.sso.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.nhnst.oc.sso.model.User;

/**
 * SSO API-1 form login
 * 
 * @author nhn
 *
 */
@Controller
public class FormLoginController extends AbstractLoginController {
	/**
	 * Login form or login page
	 * @param returnUrl
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/form/login.nhn", method = RequestMethod.GET)
	public ModelAndView login(@RequestParam(defaultValue="") String returnUrl,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		User user = getUserFromCookie(request);
		Map<String, String> userInfo = new HashMap<String, String>();
		userInfo.put("domain", getDomain());
		userInfo.put("returnUrl", returnUrl);
		if (user != null) {
			buildUserMap(userInfo, user);
			return new ModelAndView("user_form", userInfo);
		} else {
			return new ModelAndView("login", userInfo);
		}
	}

	/**
	 * Do login
	 * 
	 * @param usercode
	 * @param username
	 * @param email
	 * @param phone
	 * @param returnUrl
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/form/login.nhn", method = RequestMethod.POST)
	public ModelAndView submitLogin(@RequestParam String usercode,
			@RequestParam(defaultValue="") String username,
			@RequestParam(defaultValue="") String email,
			@RequestParam(defaultValue="") String phone,
			@RequestParam(defaultValue="") String returnUrl,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		// -----------------------
		
		// TODO check user login
		// Check user input info & do login.
		// Save user login info
		
		// -----------------------
		
		User user = new User();
		user.setUserCode(usercode);
		user.setUserName(username);
		user.setEmail(email);
		user.setPhone(phone);
		createUserCookie(user, response);
		
		Map<String, String> userInfo = new HashMap<String, String>();
		userInfo.put("domain", getDomain());
		userInfo.put("returnUrl", returnUrl);
		buildUserMap(userInfo, user);
		return new ModelAndView("user_form", userInfo);
	}

	/**
	 * Clear cookie for logout
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/logout.nhn", method = RequestMethod.GET)
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws Exception {
		clearUserCookie(request, response);
		Map<String, String> userInfo = new HashMap<String, String>();
		userInfo.put("domain", getDomain());
		return new ModelAndView("login", userInfo);
	}

	/**
	 * Check user is login
	 * 
	 * @param request
	 * @return logined: (login: true); not login: (login: flase)
	 */
	@ResponseBody
	@RequestMapping(value = "/api/login/status.nhn", method = RequestMethod.GET)
	public Map<String, Boolean> loginStatus(HttpServletRequest request, HttpServletResponse response) {
		User user = getUserFromCookie(request);
		Map<String, Boolean> map = new HashMap<String, Boolean>();
		map.put("login", user != null);
		response.addHeader("Access-Control-Allow-Origin", request.getHeader("origin"));
		response.addHeader("Access-Control-Allow-Credentials", "true");
		return map;
	}
	
	protected void buildUserMap(Map<String, String> userInfo, User user) throws Exception {
		userInfo.put("service", getServiceId());
		userInfo.put("usercode", user.getUserCode());
		if (StringUtils.isNotBlank(user.getUserName())) {
			userInfo.put("username", user.getUserName());
		}
		if (StringUtils.isNotBlank(user.getEmail())) {
			userInfo.put("email", user.getEmail());
		}
		if (StringUtils.isNotBlank(user.getPhone())) {
			userInfo.put("phone", user.getPhone());
		}
		Long time = new Date().getTime();
		userInfo.put("time", time.toString());
		userInfo.put("token", getSHA256Token(getServiceId(), user, userInfo.get("returnUrl"), time));
	}
}

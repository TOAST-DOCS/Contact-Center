package com.nhnst.oc.sso.service;

public interface SecureService {
	
	public String encrypt(String value);
	
	public String decrypt(String value);

}

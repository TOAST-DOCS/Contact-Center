package com.nhnst.oc.sso.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import cn.hutool.crypto.SecureUtil;
import cn.hutool.crypto.symmetric.DES;

@Service
public class SecureServiceDesImpl implements SecureService {
	
	@Value("${secure.key:sso-sample}")
	private String secureKey;

	public String encrypt(String value) {
		DES des = SecureUtil.des(secureKey.getBytes());
		return des.encryptBase64(value);
	}

	public String decrypt(String value) {
		DES des = SecureUtil.des(secureKey.getBytes());
		return des.decryptStr(value);
	}

}

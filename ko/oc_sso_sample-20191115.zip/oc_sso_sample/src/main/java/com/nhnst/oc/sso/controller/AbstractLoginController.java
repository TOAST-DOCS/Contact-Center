package com.nhnst.oc.sso.controller;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.util.WebUtils;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nhnst.oc.sso.model.User;
import com.nhnst.oc.sso.service.SecureService;

public abstract class AbstractLoginController {
	
	private final static String COOKIE_NAME = "sso_test_login";
	
	@Value("${oc.service}")
	private String serviceId;
	
	@Value("${oc.apikey}")
	private String apiKey;
	
	@Value("${oc.domain}")
	private String domain;
	
	@Autowired
	private SecureService secureService;
	
	private ObjectMapper mapper = new ObjectMapper().disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);

	public String getServiceId() {
		return serviceId;
	}

	public String getDomain() {
		return domain;
	}
	
	protected User getUserFromCookie(HttpServletRequest request) {
		Cookie cookie = WebUtils.getCookie(request, COOKIE_NAME);
		User user = null;
		if (cookie != null) {
			try {
				String json = secureService.decrypt(cookie.getValue());
				user = mapper.readValue(json, User.class);
			} catch (Exception e) {
				user = null;
				e.printStackTrace();
			}
		}
		return user;
	}
	
	protected void createUserCookie(User user, HttpServletResponse response) throws Exception {
		String json = mapper.writeValueAsString(user);
		String value = secureService.encrypt(json);
		Cookie cookie = new Cookie(COOKIE_NAME, value);
		cookie.setMaxAge(-1);
		cookie.setPath("/");
		response.addCookie(cookie);
		Cookie cookie1 = new Cookie("usercode", user.getUserCode());
		cookie1.setMaxAge(-1);
		cookie1.setPath("/");
		response.addCookie(cookie1);
	}
	
	protected void clearUserCookie(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Cookie cookie = WebUtils.getCookie(request, COOKIE_NAME);
		if (cookie != null) {
			cookie.setMaxAge(0);
			cookie.setPath("/");
			response.addCookie(cookie);
		}
		cookie = WebUtils.getCookie(request, "usercode");
		if (cookie != null) {
			cookie.setMaxAge(0);
			cookie.setPath("/");
			response.addCookie(cookie);
		}
	}
	
	protected String getSHA256Token(String serviceId, User user, String returnUrl, Long time) throws Exception {
		StringBuilder sb = new StringBuilder();
		// Order by following number:
		sb.append(serviceId); // 1
		sb.append("&");
		sb.append(user.getUserCode()); // 2
		sb.append("&");
		if (StringUtils.isNotBlank(user.getUserName())) {
			sb.append(user.getUserName()); // 3
			sb.append("&");
		}
		if (StringUtils.isNotBlank(user.getEmail())) {
			sb.append(user.getEmail()); // 4
			sb.append("&");
		}
		if (StringUtils.isNotBlank(user.getPhone())) {
			sb.append(user.getPhone()); // 5
			sb.append("&");
		}
		if (StringUtils.isNotBlank(returnUrl)) {
			sb.append(returnUrl); // 6
			sb.append("&");
		}
		sb.append(time); // 7
		SecretKeySpec signingKey = new SecretKeySpec(apiKey.getBytes("UTF-8"), "HmacSHA256");
		Mac mac = Mac.getInstance("HmacSHA256");
		mac.init(signingKey);
		byte[] rawHmac = mac.doFinal(sb.toString().getBytes("UTF-8"));
		StringBuilder sb1 = new StringBuilder();
		for (byte item : rawHmac) {
			sb1.append(Integer.toHexString((item & 0xFF) | 0x100).substring(1, 3));
		}
		return sb1.toString();
	}

}

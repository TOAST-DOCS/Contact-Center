package com.nhnst.oc.sso.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nhnst.oc.sso.model.User;

import okhttp3.Call;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * SSO API-2 api login
 * 
 * @author nhn
 *
 */
@Controller
public class ApiLoginController extends AbstractLoginController {
	
	private final Log logger = LogFactory.getLog(ApiLoginController.class);
	
	private OkHttpClient client = new OkHttpClient.Builder()
			.followSslRedirects(false)
			.readTimeout(60, TimeUnit.SECONDS)
			.connectTimeout(10, TimeUnit.SECONDS)
			.build();
	
	@RequestMapping(value = "/api/login.nhn", method = RequestMethod.GET)
	public ModelAndView login(@RequestParam(defaultValue="") String returnUrl,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		User user = getUserFromCookie(request);
		if (user != null) {
			Long time = postSsoAPI(user, returnUrl);
			if (time != null) {
				StringBuilder url = new StringBuilder(returnUrl);
				if (StringUtils.contains(returnUrl, "?")) {
					url.append("&usercode=").append(user.getUserCode());
				} else {
					url.append("?usercode=").append(user.getUserCode());
				}
				url.append("&time=").append(time);
				return new ModelAndView("redirect:" + url.toString());
			}
		}
		
		Map<String, String> userInfo = new HashMap<String, String>();
		userInfo.put("domain", getDomain());
		userInfo.put("returnUrl", returnUrl);
		return new ModelAndView("login", userInfo);
	}
	
	@RequestMapping(value = "/api/login.nhn", method = RequestMethod.POST)
	public ModelAndView submitLogin(@RequestParam String usercode,
			@RequestParam(defaultValue="") String username,
			@RequestParam(defaultValue="") String email,
			@RequestParam(defaultValue="") String phone,
			@RequestParam(defaultValue="") String returnUrl,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO check user login
		User user = new User();
		user.setUserCode(usercode);
		user.setUserName(username);
		user.setEmail(email);
		user.setPhone(phone);
		createUserCookie(user, response);
		
		Long time = postSsoAPI(user, returnUrl);
		if (time != null) {
			StringBuilder url = new StringBuilder(returnUrl);
			if (StringUtils.contains(returnUrl, "?")) {
				url.append("&usercode=").append(user.getUserCode());
			} else {
				url.append("?usercode=").append(user.getUserCode());
			}
			url.append("&time=").append(time);
			return new ModelAndView("redirect:" + url.toString());
		}
		
		return null;
	}
	
	private Long postSsoAPI(User user, String returnUrl) throws Exception {
		FormBody.Builder formBuilder = new FormBody.Builder();
		formBuilder.add("service", getServiceId());
		formBuilder.add("usercode", user.getUserCode());
		formBuilder.add("username", user.getUserName());
		formBuilder.add("email", user.getEmail());
		formBuilder.add("phone", user.getPhone());
		Long time = new Date().getTime();
		formBuilder.add("time", time.toString());
		formBuilder.add("token", getSHA256Token(getServiceId(), user, returnUrl, time));
		StringBuilder url = new StringBuilder();
		url.append("https://").append(getDomain()).append("/api/v2/enduser/remote.json");
		Request.Builder builder = new Request.Builder()
				.url(url.toString())
				.post(formBuilder.build());
		Request req = builder.build();
		Call call = client.newCall(req);
		Response response = call.execute();
		if (response.isSuccessful()) {
			return time;
		} else {
			logger.error("[oc api] response code = " + response.code() + ", body = " + response.body().string());
			return null;
		}
	}

}

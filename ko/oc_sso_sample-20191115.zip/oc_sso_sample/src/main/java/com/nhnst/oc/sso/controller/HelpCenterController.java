package com.nhnst.oc.sso.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

/**
 * SSO API-1 form login
 * 
 * @author nhn
 *
 */
@Controller
public class HelpCenterController extends AbstractLoginController {

	/**
	 * Login form or login page
	 * @param returnUrl
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/help/index.nhn", method = RequestMethod.GET)
	public ModelAndView help(@RequestParam(defaultValue="") String returnUrl,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map<String, String> userInfo = new HashMap<String, String>();
		userInfo.put("domain", getDomain());

		return new ModelAndView("help_frame", userInfo);
	}
}
